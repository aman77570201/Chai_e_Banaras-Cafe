package com.chaiebanaras.cafe.dao;

import java.util.List;
import com.chaiebanaras.cafe.model.Item;

public interface ItemDAO {
    List<Item> getAllItems();
    Item findById(int id);
    void addItem(Item item);
    void deleteItem(Item item);
}
