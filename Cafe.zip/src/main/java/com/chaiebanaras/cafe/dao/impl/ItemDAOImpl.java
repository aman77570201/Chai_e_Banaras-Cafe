package com.chaiebanaras.cafe.dao.impl;

import java.util.*;
import com.chaiebanaras.cafe.dao.ItemDAO;
import com.chaiebanaras.cafe.model.Item;

public class ItemDAOImpl implements ItemDAO {

    private final List<Item> items = new ArrayList<>();

    public ItemDAOImpl() {
        seedData();
    }

    @Override
    public List<Item> getAllItems() {
        return items;
    }

    @Override
    public Item findById(int id) {
        for (Item it : items)
            if (it.getId() == id) return it;
        return null;
    }

    @Override
    public void addItem(Item item) {
        items.add(item);
    }

    @Override
    public void deleteItem(Item item) {
        items.remove(item);
    }

    private void seedData() {
        int id = 1;

        String[][] names = {
            {"Banarasi Masala Chai","Adrak Chai","Elaichi Chai","Ginger Lemon Chai","Kulhad Chai",
             "Tulsi Chai","Honey Lemon Chai","Black Tea","Kashmiri Kahwa","Special Banarasi Chai"},
            {"Samosa","Bread Pakora","Kachori","Veg Cutlet","Paneer Pakora",
             "French Fries","Aloo Tikki","Veg Momos","Cheese Sandwich","Poha"},
            {"Veg Sandwich","Paneer Roll","Veg Burger","Maggi","Veg Fried Rice",
             "Veg Noodles","Paneer Butter Masala","Dal Tadka","Jeera Rice","Veg Thali"},
            {"Cold Coffee","Lemon Soda","Butter Milk","Mineral Water","Cold Drink",
             "Fresh Lime Water","Mango Shake","Banana Shake","Chocolate Shake","Rose Milk"},
            {"Gulab Jamun","Rasgulla","Jalebi","Kaju Katli","Rasmalai",
             "Ladoo","Barfi","Gajar Halwa","Peda","Sandesh"}
        };

        int[][] prices = {
            {20,25,25,30,35,30,30,20,40,45},
            {15,25,20,30,40,50,25,60,55,35},
            {50,60,70,40,80,75,120,90,70,150},
            {80,40,30,20,40,35,60,50,70,45},
            {30,30,25,60,40,25,35,50,30,40}
        };

        for (int c = 0; c < 5; c++)
            for (int i = 0; i < 10; i++)
                items.add(new Item(id++, names[c][i], prices[c][i], 50, c));
    }
}
