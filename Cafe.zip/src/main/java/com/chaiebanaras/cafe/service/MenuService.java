package com.chaiebanaras.cafe.service;

public interface MenuService {

    void viewMenu();
    void placeOrder();
    void viewCart();
    void showOffers();
    void generateBill();
    void giveFeedback();

    void adminLogin();
}
