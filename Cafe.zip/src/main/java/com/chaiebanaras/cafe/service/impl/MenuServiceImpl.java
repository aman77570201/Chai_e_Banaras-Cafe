package com.chaiebanaras.cafe.service.impl;

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.chaiebanaras.cafe.dao.ItemDAO;
import com.chaiebanaras.cafe.model.Item;
import com.chaiebanaras.cafe.model.Feedback;
import com.chaiebanaras.cafe.service.MenuService;

public class MenuServiceImpl implements MenuService {

    /* ================= FIELDS ================= */

    private ItemDAO itemDAO;
    private Scanner sc = new Scanner(System.in);

    private Map<Item, Integer> cart = new LinkedHashMap<>();
    private List<Feedback> feedbackList = new ArrayList<>();

    private String[] categories = {"Tea", "Snacks", "Meals", "Drinks", "Sweets"};
    private int[] discounts = {5, 10, 15, 8, 12};

    /* ================= CONSTRUCTOR ================= */

    public MenuServiceImpl(ItemDAO itemDAO) {
        this.itemDAO = itemDAO;
    }

    /* ================= CUSTOMER ================= */

    @Override
    public void viewMenu() {
        int lastCat = -1;
        for (Item it : itemDAO.getAllItems()) {
            if (it.getCategory() != lastCat) {
                lastCat = it.getCategory();
                System.out.println("\n--- " + categories[lastCat] + " ---");
            }
            System.out.println(it.getId() + ". " + it.getName() + "  ₹" + it.getPrice());
        }
    }

    @Override
    public void placeOrder() {
        viewMenu();
        System.out.print("\nEnter Item ID (1–50): ");
        int id = sc.nextInt();
        System.out.print("Enter Quantity: ");
        int qty = sc.nextInt();

        Item it = itemDAO.findById(id);
        if (it == null || qty > it.getStock()) {
            System.out.println("Invalid item or insufficient stock!");
            return;
        }

        it.setStock(it.getStock() - qty);
        cart.put(it, cart.getOrDefault(it, 0) + qty);

        System.out.println("✅ Order placed successfully!");
    }

    @Override
    public void viewCart() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty!");
            return;
        }
        System.out.println("\n--- YOUR CART ---");
        for (Item it : cart.keySet()) {
            System.out.println(it.getName() + " x " + cart.get(it));
        }
    }

    @Override
    public void showOffers() {
        System.out.println("\n--- AVAILABLE OFFERS ---");
        for (int i = 0; i < categories.length; i++) {
            System.out.println(categories[i] + " : " + discounts[i] + "% OFF");
        }
    }

    @Override
    public void generateBill() {

        if (cart.isEmpty()) {
            System.out.println("Cart is empty!");
            return;
        }

        sc.nextLine();
        System.out.print("Customer Name: ");
        String customer = sc.nextLine();

        int total = 0, totalDiscount = 0;

        System.out.println("\n========================================");
        System.out.println("        CHAI-E-BANARAS CAFÉ");
        System.out.println("========================================");
        System.out.println("Customer : " + customer + "\n");

        System.out.printf("%-20s %-18s %6s %8s\n",
                "Item", "Calculation", "Disc%", "DiscAmt");
        System.out.println("------------------------------------------------------");

        for (Item it : cart.keySet()) {
            int qty = cart.get(it);
            int amt = it.getPrice() * qty;
            int discAmt = amt * discounts[it.getCategory()] / 100;

            total += amt;
            totalDiscount += discAmt;

            String calc = qty + " x " + it.getPrice() + " = " + amt;

            System.out.printf("%-20s %-18s %6d %8d\n",
                    it.getName(), calc, discounts[it.getCategory()], discAmt);
        }

        System.out.println("------------------------------------------------------");
        System.out.printf("%-40s ₹%d\n", "Total Amount", total);
        System.out.printf("%-40s ₹%d\n", "Total Discount", totalDiscount);
        System.out.printf("%-40s ₹%d\n", "Payable Amount", (total - totalDiscount));

        LocalDateTime now = LocalDateTime.now();
        System.out.println("\nDate : " +
                now.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) +
                "    Time : " +
                now.format(DateTimeFormatter.ofPattern("HH:mm:ss")));

        System.out.println("\n        Visit Again ☕");
        System.out.println("     Chai-e-Banaras Café");
        System.out.println("========================================");
    }

    @Override
    public void giveFeedback() {
        System.out.print("Rate us (1–5): ");
        int r = sc.nextInt();
        sc.nextLine();
        System.out.print("Your feedback: ");
        String fb = sc.nextLine();

        feedbackList.add(new Feedback(r, fb));
        System.out.println("Thank you for your feedback!");
    }

    /* ================= ADMIN ================= */

    @Override
    public void adminLogin() {
        System.out.print("admin Username: ");
        String u = sc.next();
        System.out.print("admin Password: ");
        String p = sc.next();

        if (!u.equals("admin") || !p.equals("010705")) {
            System.out.println("Invalid credentials!");
            return;
        }

        int ch;
        do {
            System.out.println("\n================ ADMIN PANEL ================");
            System.out.println("1. Inventory (Category Wise)");
            System.out.println("2. Add Item");
            System.out.println("3. Delete Item");
            System.out.println("4. Update Item");
            System.out.println("5. View Customer Feedback");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter choice: ");

            ch = sc.nextInt();

            switch (ch) {
                case 1: adminInventory(); break;
                case 2: adminAddItem(); break;
                case 3: adminDeleteItem(); break;
                case 4: adminUpdateItem(); break;
                case 5: adminViewFeedback(); break;
                case 6: break;
                default: System.out.println("Invalid choice!");
            }
        } while (ch != 6);
    }

    /* ================= ADMIN HELPERS ================= */

    private void adminInventory() {
        System.out.println("\nSelect Category:");
        for (int i = 0; i < categories.length; i++)
            System.out.println((i + 1) + ". " + categories[i]);

        int c = sc.nextInt() - 1;

        System.out.println("\n--- " + categories[c] + " INVENTORY ---");
        for (Item it : itemDAO.getAllItems()) {
            if (it.getCategory() == c) {
                System.out.println(it.getId() + ". " + it.getName()
                        + " | ₹" + it.getPrice()
                        + " | Stock: " + it.getStock());
            }
        }
    }

    private void adminAddItem() {
        sc.nextLine();
        System.out.print("Item Name: ");
        String name = sc.nextLine();

        System.out.print("Price: ");
        int price = sc.nextInt();

        System.out.print("Stock: ");
        int stock = sc.nextInt();

        System.out.println("Select Category:");
        for (int i = 0; i < categories.length; i++)
            System.out.println((i + 1) + ". " + categories[i]);

        int c = sc.nextInt() - 1;

        int newId = itemDAO.getAllItems().size() + 1;
        itemDAO.addItem(new Item(newId, name, price, stock, c));

        System.out.println("Item added successfully!");
    }

    private void adminDeleteItem() {
        System.out.print("Enter Item ID to delete: ");
        int id = sc.nextInt();

        Item it = itemDAO.findById(id);
        if (it == null) {
            System.out.println("Invalid Item ID!");
            return;
        }

        itemDAO.deleteItem(it);
        cart.remove(it);

        System.out.println("Item deleted successfully!");
    }

    private void adminUpdateItem() {
        System.out.print("Enter Item ID to update: ");
        int id = sc.nextInt();

        Item it = itemDAO.findById(id);
        if (it == null) {
            System.out.println("Invalid Item ID!");
            return;
        }

        System.out.print("New Price: ");
        it.setPrice(sc.nextInt());

        System.out.print("New Stock: ");
        it.setStock(sc.nextInt());

        System.out.println("Item updated successfully!");
    }

    private void adminViewFeedback() {
        if (feedbackList.isEmpty()) {
            System.out.println("No feedback available!");
            return;
        }

        System.out.println("\n--- CUSTOMER FEEDBACK ---");
        int i = 1;
        for (Feedback f : feedbackList) {
            System.out.println(i++ + ". Rating: " + f.getRating());
            System.out.println("   Feedback: " + f.getComment());
        }
    }
}
