package com.chaiebanaras.cafe.model;

public class Item {
    private int id;
    private String name;
    private int price;
    private int stock;
    private int category;

    public Item(int id, String name, int price, int stock, int category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.category = category;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getPrice() { return price; }
    public int getStock() { return stock; }
    public int getCategory() { return category; }

    public void setPrice(int price) { this.price = price; }
    public void setStock(int stock) { this.stock = stock; }
}
