package com.chaiebanaras.cafe.controller;

import java.util.Scanner;
import com.chaiebanaras.cafe.service.MenuService;

public class CustomerController {

    private final MenuService menuService;
    private final Scanner sc = new Scanner(System.in);

    public CustomerController(MenuService menuService) {
        this.menuService = menuService;
    }

    public void start() {
        int choice;
        do {
            System.out.println("\n====================================");
            System.out.println("   Welcome to Chai-e-Banaras Café");
            System.out.println("====================================");
            System.out.println("1. View Menu");
            System.out.println("2. Place Order");
            System.out.println("3. View Cart");
            System.out.println("4. View Offers");
            System.out.println("5. Generate Bill");
            System.out.println("6. Give Feedback");
            System.out.println("7. Admin Login");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1: menuService.viewMenu(); break;
                case 2: menuService.placeOrder(); break;
                case 3: menuService.viewCart(); break;
                case 4: menuService.showOffers(); break;
                case 5: menuService.generateBill(); break;
                case 6: menuService.giveFeedback(); break;
                case 7: menuService.adminLogin(); break;
                case 8: System.out.println("Thank you!"); break;
                default: System.out.println("Invalid choice!");
            }
        } while (choice != 8);
    }
}
