package com.chaiebanaras.cafe.app;

import com.chaiebanaras.cafe.controller.CustomerController;
import com.chaiebanaras.cafe.dao.ItemDAO;
import com.chaiebanaras.cafe.dao.impl.ItemDAOImpl;
import com.chaiebanaras.cafe.service.MenuService;
import com.chaiebanaras.cafe.service.impl.MenuServiceImpl;

public class MainApp {
    public static void main(String[] args) {

        ItemDAO itemDAO = new ItemDAOImpl();
        MenuService menuService = new MenuServiceImpl(itemDAO);
        CustomerController controller = new CustomerController(menuService);

        controller.start();
    }
}
